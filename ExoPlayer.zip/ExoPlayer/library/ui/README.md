# ExoPlayer UI library module #

Provides UI components and resources for use with ExoPlayer.

## Links ##

* [Javadoc][]: Classes matching `com.google.android.exoplayer2.ui.*`
  belong to this module.

[Javadoc]: https://google.github.io/ExoPlayer/doc/reference/index.html
